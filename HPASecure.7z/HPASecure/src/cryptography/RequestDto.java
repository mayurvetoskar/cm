/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cryptography;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY, getterVisibility =
JsonAutoDetect.Visibility.NONE, setterVisibility = JsonAutoDetect.Visibility.NONE, creatorVisibility =
JsonAutoDetect.Visibility.NONE)
/**
 *
 * @author Administrator
 */
class RequestDto {
private String clientId;
private String encData;

public String getClientId() {
return clientId;
}
public void setClientId(String clientId) {
this.clientId = clientId;
}
public String getEncData() {
return encData;
}
public void setEncData(String encData) {
this.encData = encData;
}

}
