/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cryptography;

/**
 *
 * @author Administrator
 */
class AddtionObj {
    private String chasiNo;
    private String eng_no;
    private String hpa_from;
    private String hpa_upto;
    private String docurl;
    private String userId;
    private String userPwd;
    public String getChasiNo() {
    return chasiNo;

    }
    public void setChasiNo(String chasiNo) {
    this.chasiNo = chasiNo;
    }
    public String getEng_no() {
    return eng_no;
    }
    public void setEng_no(String eng_no) {
    this.eng_no = eng_no;
    }
    public String getHpa_from() {
    return hpa_from;
    }
    public void setHpa_from(String hpa_from) {
    this.hpa_from = hpa_from;
    }
    public String getHpa_upto() {
    return hpa_upto;
    }
    public void setHpa_upto(String hpa_upto) {
    this.hpa_upto = hpa_upto;
    }
    public String getDocurl() {
    return docurl;
    }
    public void setDocurl(String docurl) {
    this.docurl = docurl;
    }
    public String getUserId() {
    return userId;
    }
    public void setUserId(String userId) {
    this.userId = userId;
    }
    public String getUserPwd() {
    return userPwd;
    }
    public void setUserPwd(String userPwd) {
    this.userPwd = userPwd;
    }
    
}
