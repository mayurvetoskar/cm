/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cryptography;

import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
//import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 *
 * @author Administrator
 */
public class CryptoMain {
    private static final String ENCRYPT_ALGO = "AES/GCM/NoPadding";
    private static final int TAG_LENGTH_BIT = 128;
    private static final int IV_LENGTH_BYTE = 12;
    private static final int SALT_LENGTH_BYTE = 16;
    private static final Charset UTF_8 = StandardCharsets.UTF_8;
    
    public static String encrypt(byte[] pText, String key) throws Exception {
        byte[] salt = CryptoUtils.getRandomNonce(SALT_LENGTH_BYTE);
        byte[] iv = CryptoUtils.getRandomNonce(IV_LENGTH_BYTE);
        SecretKey aesKey = CryptoUtils.getAESKey(key.toCharArray(), salt);
        Cipher cipher = Cipher.getInstance(ENCRYPT_ALGO);
        cipher.init(Cipher.ENCRYPT_MODE, aesKey, new
        GCMParameterSpec(TAG_LENGTH_BIT, iv));
        byte[] cipherText = cipher.doFinal(pText);

        byte[] cipherTextWithIvSalt = ByteBuffer.allocate(iv.length + salt.length +
        cipherText.length)
        .put(iv)
        .put(salt)
        .put(cipherText)
        .array();
        //return Base64.getEncoder().encodeToString(cipherTextWithIvSalt);
        return Base64.encode(cipherTextWithIvSalt);
    }
    // we need the same password, salt and iv to decrypt it
    public static String decrypt(String cText, String key) throws Exception {
        //byte[] decode = Base64.getDecoder().decode(cText.getBytes(UTF_8));
        byte[] decode = Base64.decode(cText);
        ByteBuffer bb = ByteBuffer.wrap(decode);
        byte[] iv = new byte[IV_LENGTH_BYTE];
        bb.get(iv);
        byte[] salt = new byte[SALT_LENGTH_BYTE];
        bb.get(salt);
        byte[] cipherText = new byte[bb.remaining()];
        bb.get(cipherText);
        SecretKey aesKey = CryptoUtils.getAESKey(key.toCharArray(), salt);
        Cipher cipher = Cipher.getInstance(ENCRYPT_ALGO);
        cipher.init(Cipher.DECRYPT_MODE, aesKey, new
        GCMParameterSpec(TAG_LENGTH_BIT, iv));
        byte[] plainText = cipher.doFinal(cipherText);
        return new String(plainText, UTF_8);
    }
}
