/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cryptography;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 *
 * @author Administrator
 */
class EncryptMain {
    public static void main(String[] args) throws Exception{
        String abc = "";
        String def = "";
        AddtionObj dob = new AddtionObj();
        RequestDto dobj = new RequestDto();

        dob.setChasiNo("KNAJP811MF7044929");
        dob.setEng_no("52WVC114292");
        dob.setDocurl("");
        dob.setHpa_from("2022-08-05");
        dob.setHpa_upto("2022-09-05");
        dob.setUserId("svccoopbank");
        dob.setUserPwd("Delhi@123");
        abc = convertToJson(dob);
        String reqEncrypt = "";
        
        
        String key = "N/yAbjo/cIziX2Gq14+EDSBTgB0AskxrkhwwdGNuEII=";
        System.out.println("ddv " + key);
        reqEncrypt = CryptoMain.encrypt(abc.getBytes(), key);
        System.out.println(reqEncrypt);
        dobj.setClientId("svccoopbank");
        dobj.setEncData(reqEncrypt);
        def = convertToJson(dobj);
        System.out.println(def);
        
        String regDecrypt = "";
        regDecrypt = CryptoMain.decrypt("8KUYtXJ8uMS6JIcSfWxn84Vde2B9f9k/ZV5CNLeQKDSDoWVykbh0k+PUBgLoT3hy01OAW8J2YeDQWtZ9gocmyWWH4XhlmdKE18B8TSuHEA4fc8huqDhPWhsfTYyo0+AQJT+TRXLrsgkkNWGIGOFjTkx1Evtkt9GWLUsRXSLb2yykPHEX9O7q45dmbQQ368Y2OngKuBEv2KgC+AIbLX0DrfR+R/R+WpSfmJL0nxJgtP0PYP1zv7toEi80", key);
        System.out.println(regDecrypt);
    }
    
    public static String convertToJson(RequestDto vaTac) {
        String jsonString = "";
        ObjectMapper mapper = new ObjectMapper();
        try {
        jsonString = mapper.writeValueAsString(vaTac);
        } catch (Exception e) {
        System.out.printf(e.getMessage());
        }
        return jsonString;
    }
    
    public static String convertToJson(AddtionObj vaTac) {
    String jsonString = "";
    ObjectMapper mapper = new ObjectMapper();
    try {
    jsonString = mapper.writeValueAsString(vaTac);
    } catch (Exception e) {
    System.out.printf(e.getMessage());
    }
    return jsonString;
    }
    
}
