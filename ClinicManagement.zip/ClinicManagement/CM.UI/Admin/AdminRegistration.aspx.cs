﻿using CM.BAL;
using CM.SC;
using CM.UI.Repository;
using System;
using System.Data;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CM.UI.Admin
{
    public partial class AdminRegistration : System.Web.UI.Page
    {
        AdminBAL Obj = new AdminBAL();
        Logger ObjLogger = new Logger();

        protected void Page_Load(object sender, EventArgs e)
        {
            //if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "" || Convert.ToString(Session["UserId"]) == string.Empty)
            //{
            //    Response.Redirect("AdminLogin.aspx");
            //}

            ProfileImgUpload.Attributes["onchange"] = "UploadFile(this)";

            if (!IsPostBack)
            {
                BindDetails();
            }

        }

        protected void BindDetails()
        {
            DataTable dt = null;
            try
            {
                dt = Obj.GetCMAdminDetail(3, 0, "", "");
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        gvAdminDetail.DataSource = dt;
                        gvAdminDetail.DataBind();
                    }
                    else
                    {
                        dt = new DataTable();
                        dt.Columns.Add("CMAdminUserId", typeof(int));
                        dt.Columns.Add("Name", typeof(string));
                        dt.Columns.Add("UserName", typeof(string));
                        dt.Columns.Add("Pwd", typeof(string));
                        dt.Columns.Add("IsActive", typeof(int));
                        dt.Rows.Add(dt.NewRow());
                        gvAdminDetail.DataSource = dt;
                        gvAdminDetail.EmptyDataText = "-1";
                        gvAdminDetail.DataBind();
                        gvAdminDetail.Rows[0].Visible = false;
                    }
                }

            }
            catch (Exception ex)
            {
                ObjLogger.WriteLogfile("AdminRegistration BindDetails --> ", ex.Message.ToString());
            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                AddDiv.Visible = true;
                DetailDiv.Visible = false;
                PwdDiv.Visible = true;
            }
            catch (Exception ex)
            {
                ObjLogger.WriteLogfile("AdminRegistration btnAdd_Click --> ", ex.Message.ToString());
            }
        }

        protected void btnRegisterAdmin_Click(object sender, EventArgs e)
        {
            DataTable dt = null;
            try
            {
                if (txtFirstName.Text.Trim() == "" || txtFirstName.Text.Trim() == string.Empty || txtFirstName.Text.Trim() == null)
                {
                    ErrorMessage.ShowErrorMessage(sender, this.GetType(), "Error", "Please enter first name");
                    return;
                }
                if (txtMiddleName.Text.Trim() == "" || txtMiddleName.Text.Trim() == string.Empty || txtMiddleName.Text.Trim() == null)
                {
                    ErrorMessage.ShowErrorMessage(sender, this.GetType(), "Error", "Please enter middle name");
                    return;
                }
                if (txtLastName.Text.Trim() == "" || txtLastName.Text.Trim() == string.Empty || txtLastName.Text.Trim() == null)
                {
                    ErrorMessage.ShowErrorMessage(sender, this.GetType(), "Error", "Please enter last name");
                    return;
                }
                if (txtUserName.Text.Trim() == "" || txtUserName.Text.Trim() == string.Empty || txtUserName.Text.Trim() == null)
                {
                    ErrorMessage.ShowErrorMessage(sender, this.GetType(), "Error", "Please enter user name");
                    return;
                }
                if (txtPwd.Text.Trim() == "" || txtPwd.Text.Trim() == string.Empty || txtPwd.Text.Trim() == null)
                {
                    ErrorMessage.ShowErrorMessage(sender, this.GetType(), "Error", "Please enter password");
                    return;
                }

                string pProfileImage = string.Empty;
                if (hdnImage.Value != "" || hdnImage.Value != string.Empty)
                {
                    pProfileImage = hdnImage.Value;
                }
                if (pProfileImage == "" || pProfileImage == string.Empty || pProfileImage == null)
                {
                    ErrorMessage.ShowErrorMessage(sender, this.GetType(), "Error", "Please select profile photo");
                    return;
                }


                int AdminUserId = 0;
                if (Session["CMAdminUserId"] != null)
                {
                    AdminUserId = Convert.ToInt32(Session["CMAdminUserId"]);
                }
                                                
                if (AdminUserId == 0)
                {
                    dt = Obj.SetCMAdminDetail(1, AdminUserId, txtFirstName.Text.Trim(), txtMiddleName.Text.Trim(), txtLastName.Text.Trim(), txtUserName.Text.Trim(), txtPwd.Text.Trim(), pProfileImage, Convert.ToInt32(ChkIsActive.Checked));
                    ErrorMessage.ShowErrorMessage(sender, this.GetType(), "Success", "User register successfully.");
                }
                else
                {
                    dt = Obj.SetCMAdminDetail(2, AdminUserId, txtFirstName.Text.Trim(), txtMiddleName.Text.Trim(), txtLastName.Text.Trim(), txtUserName.Text.Trim(), txtPwd.Text.Trim(), pProfileImage, Convert.ToInt32(ChkIsActive.Checked));
                    ErrorMessage.ShowErrorMessage(sender, this.GetType(), "Success", "User data modify successfully.");
                    Session["CMAdminUserId"] = null;
                }

                AddDiv.Visible = false;
                DetailDiv.Visible = true;
                BindDetails();
            }
            catch (Exception ex)
            {
                ObjLogger.WriteLogfile("AdminRegistration btnRegisterAdmin_Click --> ", ex.Message.ToString());
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                txtFirstName.Text = "";
                txtMiddleName.Text = "";
                txtLastName.Text = "";
                txtUserName.Text = "";
                txtPwd.Text = "";
            }
            catch (Exception ex)
            {
                ObjLogger.WriteLogfile("AdminRegistration btnReset_Click --> ", ex.Message.ToString());
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                AddDiv.Visible = false;
                DetailDiv.Visible = true;
                BindDetails();
                Session["CMAdminUserId"] = null;
            }
            catch (Exception ex)
            {
                ObjLogger.WriteLogfile("AdminRegistration btnCancel_Click --> ", ex.Message.ToString());
            }
        }

        protected void gvAdminDetail_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            DataTable dt = null;
            if (e.CommandName == "Change")
            {
                int rowIndex = int.Parse(e.CommandArgument.ToString());
                int CMAdminUserId = (int)this.gvAdminDetail.DataKeys[rowIndex].Value;
                Session["CMAdminUserId"] = CMAdminUserId;
                dt = Obj.GetCMAdminDetail(4, CMAdminUserId, "", "");
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        txtFirstName.Text = dt.Rows[0]["FirstName"].ToString();
                        txtMiddleName.Text = dt.Rows[0]["MiddleName"].ToString();
                        txtLastName.Text = dt.Rows[0]["LastName"].ToString();
                        txtUserName.Text = dt.Rows[0]["UserName"].ToString();
                        txtPwd.Text = dt.Rows[0]["Pwd"].ToString();
                        PwdDiv.Visible = false;
                        if (dt.Rows[0]["ProfileImage"].ToString() == "")
                        {
                            ProfileImg.ImageUrl = "~/images/NoImage.jpg";
                            hdnImage.Value = "";
                        }
                        else
                        {
                            ProfileImg.ImageUrl = "data:image;base64," + dt.Rows[0]["ProfileImage"].ToString();                                                        
                            hdnImage.Value = dt.Rows[0]["ProfileImage"].ToString();
                        }
                        if (Convert.ToInt32(dt.Rows[0]["IsActive"]) == 1)
                        {
                            ChkIsActive.Checked = true;
                        }
                        else
                        {
                            ChkIsActive.Checked = false;
                        }
                        AddDiv.Visible = true;
                        DetailDiv.Visible = false;
                    }
                    else
                    {
                        ErrorMessage.ShowErrorMessage(sender, this.GetType(), "Error", "Data not found.");
                    }
                }
                else
                {
                    ErrorMessage.ShowErrorMessage(sender, this.GetType(), "Error", "Data not found.");
                }

            }
            else if (e.CommandName == "Remove")
            {
                int rowIndex = int.Parse(e.CommandArgument.ToString());
                int CMAdminUserId = (int)this.gvAdminDetail.DataKeys[rowIndex].Value;

                dt = Obj.SetCMAdminDetail(4, CMAdminUserId, "", "", "", "", "", "", 0);
                ErrorMessage.ShowErrorMessage(sender, this.GetType(), "Success", "User remove successfully.");
                AddDiv.Visible = false;
                DetailDiv.Visible = true;
                BindDetails();
            }

        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            //ErrorMessage.ShowErrorMessage(sender, this.GetType(), "Success", "Image Upload.");
            BinaryReader br = new BinaryReader(ProfileImgUpload.PostedFile.InputStream);
            byte[] bytes = br.ReadBytes((int)ProfileImgUpload.PostedFile.InputStream.Length);

            //Convert the Byte Array to Base64 Encoded string.
            string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);

            //Convert Base64 Encoded string to Byte Array.
            byte[] imageBytes = Convert.FromBase64String(base64String);

            ProfileImg.ImageUrl = "data:image;base64," + Convert.ToBase64String(imageBytes);
            hdnImage.Value = base64String.ToString();
        }

        public static string ImagePathToBase64(string path)
        {
            System.Drawing.Image image = System.Drawing.Image.FromFile(path);
            MemoryStream m = new MemoryStream();
            image.Save(m, image.RawFormat);
            byte[] imageBytes = m.ToArray();
            string base64String = Convert.ToBase64String(imageBytes);
            return base64String;
        }
    }
}