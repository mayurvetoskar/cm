﻿using CM.BAL;
using CM.SC;
using CM.UI.Repository;
using System;
using System.Data;
using System.Web.UI;

namespace CM.UI.Admin
{
    public partial class AdminLogin : System.Web.UI.Page
    {
        AdminBAL Obj = new AdminBAL();
        Logger ObjLogger = new Logger();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

            }
        }

        protected void btnAdminLogin_Click(object sender, EventArgs e)
        {
            DataTable dt = null;
            try
            {
                dt = Obj.GetCMAdminDetail(1, 0, txtUserName.Text.Trim(), txtPwd.Text.Trim());
                if (dt != null)
                {
                    if (dt.Rows.Count == 0)
                    {                        
                        ErrorMessage.ShowErrorMessage(sender, this.GetType(), "Error", "Login Faild!");
                        Session["UserId"] = null;
                        return;
                    }
                    else
                    {
                        Session["UserId"] = dt.Rows[0]["CMAdminUserId"];
                        Response.Redirect("AdminRegistration.aspx");
                    }
                }
            }
            catch (Exception ex)
            {
                ObjLogger.WriteLogfile("btnAdminLogin_Click --> ", ex.Message.ToString());
            }
        }
    }
}