﻿using CM.BAL;
using CM.SC;
using CM.UI.Repository;
using System;
using System.Data;

namespace CM.UI.Admin
{
    public partial class ChangePwd : System.Web.UI.Page
    {
        AdminBAL Obj = new AdminBAL();
        Logger ObjLogger = new Logger();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserId"] == null || Convert.ToString(Session["UserId"]) == "" || Convert.ToString(Session["UserId"]) == string.Empty)
            {
                Response.Redirect("AdminLogin.aspx");
            }
        }

        protected void btnChangePwd_Click(object sender, EventArgs e)
        {
            DataTable dt = null;
            try
            {
                dt = Obj.GetCMAdminDetail(2, Convert.ToInt32(Session["UserId"]), "", txtOldPwd.Text.Trim());
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        if (txtNewPwd.Text.Trim() == txtOldPwd.Text.Trim())
                        {
                            ErrorMessage.ShowErrorMessage(sender, this.GetType(), "Error", "old password and new password should not be same.");
                            return;
                        }
                        if (txtNewPwd.Text.Trim() == txtConfirmPwd.Text.Trim())
                        {
                            Obj.SetCMAdminDetail(3, Convert.ToInt32(Session["UserId"]), "", "", "", "", txtNewPwd.Text.Trim(),"", 1);
                        }
                        else
                        {
                            ErrorMessage.ShowErrorMessage(sender, this.GetType(), "Error", "new password and confirm password does not match.");
                        }
                    }
                    else
                    {
                        ErrorMessage.ShowErrorMessage(sender, this.GetType(), "Error", "old password dose not match.");
                    }
                }
                else
                {
                    ErrorMessage.ShowErrorMessage(sender, this.GetType(), "Error", "old password dose not match.");
                }
            }
            catch (Exception ex)
            {
                ObjLogger.WriteLogfile("ChangePwd btnChangePwd_Click --> ", ex.Message.ToString());
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                txtOldPwd.Text = "";
                txtNewPwd.Text = "";
                txtConfirmPwd.Text = "";
            }
            catch (Exception ex)
            {
                ObjLogger.WriteLogfile("ChangePwd btnReset_Click --> ", ex.Message.ToString());
            }
        }

    }
}