﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;

namespace CM.UI.Repository
{
    public class ErrorMessage
    {
        public static void ShowErrorMessage(object sender,Type type, string ErrorTitle, string Message)
        {
            ScriptManager.RegisterClientScriptBlock((sender as Control), type, "Messages", "showMessageBox('" + ErrorTitle + "','" + Message + "')", true);
        }

    }
}