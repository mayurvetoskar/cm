﻿
function ConvertToCamelCase(e) {

    var name = e.value.split(' ')
    var data = ''
    for (i = 0; i < name.length; i++) {
        if (i == 0) {
            data = name[i].charAt(0).toUpperCase() + name[i].slice(1).toLowerCase()
        }
        else {
            data = data + ' ' + name[i].charAt(0).toUpperCase() + name[i].slice(1).toLowerCase()
        }
    }
    e.value = data
}

function onlyAlphabets(e, t) {
    if (window.event) {
        var charCode = window.event.keyCode;
    }
    else if (e) {
        var charCode = e.which;
    }
    else { return true; }
    if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123))
        return true;
    else
        return false;
}

function allowOnlyNumber(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}

function showMessageBox(Title, Msg) {
    $("#ErrorHead").text(Title);
    if (Title == "Error") {
        $("#Errordiv").attr("class", "sufee-alert alert with-close alert-danger alert-dismissible fade show");
        $("#ErrorTitle").attr("class", "badge badge-pill badge-danger");
    }
    else {
        $("#Errordiv").attr("class", "sufee-alert alert with-close alert-success alert-dismissible fade show");
        $("#ErrorTitle").attr("class", "badge badge-pill badge-success");
    }
    $("#ErrorTitle").text(Title);
    $("#ErrorMsg").text(Msg);
    $("#cmdFileUpload").click();
}

function UserConfirmation(ConfirmMessage) {
    return window.confirm(ConfirmMessage);
}


function AdminLogout() {
    $("#btnLogout").click();
}

function UploadFile(fileUpload) {   
    if (fileUpload.value != '') {        
        $("#ContentPlaceHolder1_btnUpload").click();
    }
}