﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CM.SC
{
    public class Logger
    {
        public const long MaxLogFileSize = 100000;

        public void WriteLogfile(string Category, string lMessage, int lSeverity = 1)
        {
            try
            {
                string lstrFileName = string.Empty;
                string lstrNewFileName = string.Empty;
                System.IO.FileInfo fInfo;
                string strFolderPath = ConfigurationManager.AppSettings["LogFile"].ToString() + "\\";

                string FileName = strFolderPath + string.Format("{0:D}", DateTime.Now.ToString("ddMMMyy")) + ".txt";
                using (StreamWriter sw = File.AppendText(FileName))
                {
                    sw.WriteLine(DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss") + ": " + Category + lMessage);
                }

                fInfo = new System.IO.FileInfo(FileName);

                if (fInfo.Length == MaxLogFileSize)
                {
                    lstrFileName = strFolderPath + string.Format("{0:D}", DateTime.Now.ToString("ddMMMyyhhmmss")) + ".txt";
                    File.Move(lstrFileName, FileName);
                }

                if (lSeverity == 9)
                {
                    System.Diagnostics.EventLog.WriteEntry(Category, lMessage);
                }
            }
            catch (Exception ex) 
            {
            }
        }

    }
}
