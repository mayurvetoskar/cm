﻿using CM.SC;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CM.DAL
{
    public class AdminDAL
    {
        Logger ObjLogger = new Logger();
        public DataTable GetCMAdminDetail(int pType, int pCMAdminUserId, string pUserName, string pPwd)
        {
            DataTable dt = new DataTable();
            try
            {
                string lsql = string.Empty;
                lsql = "Exec spGetCMAdminDetail " + pType + "," + pCMAdminUserId + ",'" + pUserName + "','" + pPwd + "'";
                dt = Common.ReturnDataTable(lsql);
            }
            catch (Exception ex)
            {
                ObjLogger.WriteLogfile("CheckAdminLogin --> ", ex.Message.ToString());
            }
            return dt;
        }

        public DataTable SetCMAdminDetail(int pType, int pCMAdminUserId, string pFirstName, string pMiddleName, string pLastName, string pUserName, string pPwd,string pProfileImage, int pIsActive)
        {
            DataTable dt = new DataTable();
            try
            {
                string lsql = string.Empty;
                lsql = "Exec spSetCMAdminDetail " + pType + "," + pCMAdminUserId + ",'" + pFirstName + "','" + pMiddleName + "','" + pLastName + "','" + pUserName + "','" + pPwd + "','"+ pProfileImage + "'," + pIsActive;
                dt = Common.ReturnDataTable(lsql);
            }
            catch (Exception ex)
            {
                ObjLogger.WriteLogfile("CheckAdminLogin --> ", ex.Message.ToString());
            }
            return dt;
        }
    }
}
