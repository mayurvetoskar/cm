﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using CM.SC;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CM.DAL
{
    public class Common
    {
        

        internal static SqlConnection myGetConnection(string pConnection = null)
        {
            Logger Obj = new Logger();
            SqlConnection lConnection;
            try
            {
                if (pConnection == null)
                    lConnection = new SqlConnection(ConfigurationSettings.AppSettings["ConStrCMDB"]);
                else
                    lConnection = new SqlConnection(pConnection);
                return lConnection;
            }
            catch (Exception ex)
            {
                Obj.WriteLogfile("Common-myGetConnection --> ", ex.Message);
                throw ex;
            }
            finally
            {
                lConnection = null/* TODO Change to default(_) if this is not a reference type */;
            }
        }

        public static DataTable ReturnDataTable(string pQueryString)
        {
            Logger Obj = new Logger();
            SqlConnection lConnection =new SqlConnection();
            DataTable lDataTable = new DataTable();
            SqlDataAdapter lSQLDataAdapter = null/* TODO Change to default(_) if this is not a reference type */;
            SqlCommand lCommand;
            try
            {
                lConnection = myGetConnection();
                lCommand = new SqlCommand();
                lCommand.Connection = lConnection;
                lCommand.CommandTimeout = 0;
                lCommand.CommandText = pQueryString;
                lSQLDataAdapter = new SqlDataAdapter(lCommand);
                lDataTable = new DataTable();
                lSQLDataAdapter.Fill(lDataTable);
                return lDataTable;
            }

            catch (Exception ex)
            {
                Obj.WriteLogfile("Common-ReturnDataTable --> ", ex.Message);
                throw ex;
            }
            finally
            {
                lSQLDataAdapter.Dispose();
                lSQLDataAdapter = null/* TODO Change to default(_) if this is not a reference type */;
                lConnection.Close();// lConnection.Dispose()
                lDataTable = null/* TODO Change to default(_) if this is not a reference type */;
                lConnection = null/* TODO Change to default(_) if this is not a reference type */;
            }
        }

        public static DataSet ReturnDataSet(string pQueryString)
        {
            Logger Obj = new Logger();
            SqlDataAdapter lSQLDataAdapter =new SqlDataAdapter();
            DataSet lDataset;
            SqlConnection lconnection=new SqlConnection();
            SqlCommand lobjCommand = new SqlCommand();
            try
            {
                // lconnection = myGetConnection()

                // lSQLDataAdapter = New SqlDataAdapter(pQueryString, lconnection)
                // lDataset = New DataSet
                // lSQLDataAdapter.Fill(lDataset)
                // Return lDataset


                lconnection = myGetConnection();

                lobjCommand.Connection = lconnection;
                lobjCommand.CommandTimeout = 0;
                lobjCommand.CommandText = pQueryString;

                // lSQLDataAdapter = New SqlDataAdapter(pQueryString, lconnection)
                lSQLDataAdapter = new SqlDataAdapter(lobjCommand);

                lDataset = new DataSet();
                lSQLDataAdapter.Fill(lDataset);
                return lDataset;
            }
            catch (Exception ex)
            {
                Obj.WriteLogfile("Common-ReturnDataSet --> ", ex.Message);
                throw ex;
            }
            finally
            {
                lSQLDataAdapter.Dispose();
                lSQLDataAdapter = null/* TODO Change to default(_) if this is not a reference type */;
                if (lconnection.State == ConnectionState.Open)
                    lconnection.Close();
                lconnection = null/* TODO Change to default(_) if this is not a reference type */;
            }
        }

       

    }
}
