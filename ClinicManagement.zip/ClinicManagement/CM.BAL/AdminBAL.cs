﻿using CM.DAL;
using CM.SC;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CM.BAL
{
    public class AdminBAL
    {
        AdminDAL ObjDAL = new AdminDAL();
        Logger ObjLogger = new Logger();
        EncryptionDecryption obj = new EncryptionDecryption();

        public DataTable GetCMAdminDetail(int pType, int pCMAdminUserId, string pUserName, string pPwd)
        {
            DataTable dt = null;
            try
            {
                dt = ObjDAL.GetCMAdminDetail(pType, pCMAdminUserId, pUserName, obj.EncryptString(pPwd));
                if (dt != null)
                {
                    return dt;
                }
            }
            catch (Exception ex)
            {
                ObjLogger.WriteLogfile("AdminBAL CheckUserLogin --> ", ex.Message.ToString());
            }
            return dt;
        }
        
        public DataTable SetCMAdminDetail(int pType, int pCMAdminUserId, string pFirstName, string pMiddleName, string pLastName, string pUserName, string pPwd,string pProfileImage, int pIsActive)
        {
            DataTable dt = null;
            try
            {
                dt = ObjDAL.SetCMAdminDetail(pType, pCMAdminUserId, pFirstName, pMiddleName, pLastName, pUserName, obj.EncryptString(pPwd), pProfileImage, pIsActive);
                if (dt != null)
                {
                    return dt;
                }
            }
            catch (Exception ex)
            {
                ObjLogger.WriteLogfile("AdminBAL CheckUserLogin --> ", ex.Message.ToString());
            }
            return dt;
        }

    }
}
